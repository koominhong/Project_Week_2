public class Constant {

    public static int PlAYER_POSITION = 0;
    public static int PLAYER_NOW_POSITION = 0;
    public static int PLAYER_NUMBER_OF_COMPLETION =0;

    public static int COMPUTER_POSITION = 0;
    public static int COMPUTER_NOW_POSITION = 0;
    public static int COMPUTER_NUMBER_OF_COMPLETION =0;

}
